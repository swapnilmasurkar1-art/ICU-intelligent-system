import {
  LayoutDashboard, Monitor, Users, AlertTriangle, Heart, Eye, ClipboardList,
  ArrowRightLeft, Activity, TrendingUp, Pill, FlaskConical, Wind, Scan,
  Stethoscope, ShieldAlert, Brain, Sparkles, TrendingDown, Bug, BarChart3,
  HelpCircle, BedDouble, Gauge, UserCog, Boxes, FileText, FileBarChart,
  History, Bell, Settings, User, HeartPulse,
} from 'lucide-react';

export interface NavItem {
  id: string;
  label: string;
  icon: typeof LayoutDashboard;
}

export interface NavSection {
  title: string;
  items: NavItem[];
}

export const navSections: NavSection[] = [
  {
    title: 'Command',
    items: [
      { id: 'command-center', label: 'Command Center', icon: LayoutDashboard },
      { id: 'icu-overview', label: 'ICU Overview', icon: Monitor },
      { id: 'live-monitor', label: 'Live Monitor', icon: HeartPulse },
    ],
  },
  {
    title: 'Patients',
    items: [
      { id: 'all-patients', label: 'All Patients', icon: Users },
      { id: 'critical-patients', label: 'Critical Patients', icon: AlertTriangle },
      { id: 'patient-watchlist', label: 'Patient Watchlist', icon: Eye },
      { id: 'admissions', label: 'Admissions', icon: ClipboardList },
      { id: 'transfers', label: 'Transfers', icon: ArrowRightLeft },
    ],
  },
  {
    title: 'Clinical',
    items: [
      { id: 'patient-monitoring', label: 'Patient Monitoring', icon: Activity },
      { id: 'vitals', label: 'Vitals', icon: Heart },
      { id: 'clinical-charts', label: 'Clinical Charts', icon: TrendingUp },
      { id: 'medications', label: 'Medications', icon: Pill },
      { id: 'labs', label: 'Labs', icon: FlaskConical },
      { id: 'ventilator', label: 'Ventilator', icon: Wind },
      { id: 'imaging', label: 'Imaging', icon: Scan },
      { id: 'procedures', label: 'Procedures', icon: Stethoscope },
    ],
  },
  {
    title: 'Care Team',
    items: [
      { id: 'nursing', label: 'Nursing Operations', icon: ShieldAlert },
      { id: 'doctors', label: 'Doctors & Specialists', icon: Stethoscope },
      { id: 'care-team', label: 'Care Team', icon: Users },
      { id: 'shift-handover', label: 'Shift Handover', icon: ArrowRightLeft },
    ],
  },
  {
    title: 'AI Intelligence',
    items: [
      { id: 'ai-copilot', label: 'AI Clinical Copilot', icon: Sparkles },
      { id: 'deterioration-risk', label: 'Deterioration Risk', icon: TrendingDown },
      { id: 'sepsis-risk', label: 'Sepsis Risk', icon: Bug },
      { id: 'organ-risk', label: 'Organ Risk', icon: Heart },
      { id: 'predictive-analytics', label: 'Predictive Analytics', icon: BarChart3 },
      { id: 'ai-explainability', label: 'AI Explainability', icon: HelpCircle },
    ],
  },
  {
    title: 'Operations',
    items: [
      { id: 'bed-management', label: 'Bed Management', icon: BedDouble },
      { id: 'ventilator-capacity', label: 'Ventilator Capacity', icon: Gauge },
      { id: 'staffing', label: 'Staffing', icon: UserCog },
      { id: 'resources', label: 'Resources', icon: Boxes },
    ],
  },
  {
    title: 'Reports',
    items: [
      { id: 'clinical-reports', label: 'Clinical Reports', icon: FileText },
      { id: 'analytics', label: 'Analytics', icon: FileBarChart },
      { id: 'audit-trail', label: 'Audit Trail', icon: History },
    ],
  },
  {
    title: 'System',
    items: [
      { id: 'alerts', label: 'Notifications', icon: Bell },
      { id: 'settings', label: 'Unit Settings', icon: Settings },
      { id: 'profile', label: 'Profile', icon: User },
    ],
  },
];

export const mobileNav = [
  { id: 'command-center', label: 'Home', icon: LayoutDashboard },
  { id: 'all-patients', label: 'Patients', icon: Users },
  { id: 'alerts', label: 'Alerts', icon: AlertTriangle },
  { id: 'ai-copilot', label: 'AI', icon: Brain },
];
