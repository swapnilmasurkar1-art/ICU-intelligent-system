export type Severity = 'critical' | 'warning' | 'stable' | 'observation';

export type BodySystem =
  | 'neurological'
  | 'cardiovascular'
  | 'respiratory'
  | 'renal'
  | 'hepatic'
  | 'musculoskeletal'
  | 'hematological'
  | 'infectious';

export type OrganKey =
  | 'brain'
  | 'heart'
  | 'lungs'
  | 'liver'
  | 'kidneys'
  | 'gastrointestinal'
  | 'vascular'
  | 'skeletal';

export interface VitalReading {
  time: string;
  value: number;
}

export interface Vital {
  key: string;
  label: string;
  icon: string;
  value: number;
  unit: string;
  normalMin: number;
  normalMax: number;
  trend: 'up' | 'down' | 'stable';
  trendValue: number;
  history: VitalReading[];
  alertThreshold?: number;
}

export interface LabValue {
  name: string;
  value: number;
  unit: string;
  refLow: number;
  refHigh: number;
  abnormal: 'high' | 'low' | 'normal';
  previous: number;
  category: string;
}

export interface Medication {
  id: string;
  drug: string;
  dose: string;
  route: string;
  frequency: string;
  startTime: string;
  nextDose: string;
  prescriber: string;
  status: 'active' | 'due-soon' | 'overdue' | 'held';
  highRisk: boolean;
}

export interface ClinicalEvent {
  time: string;
  title: string;
  description: string;
  type: 'alert' | 'intervention' | 'vital' | 'lab' | 'ai' | 'nursing' | 'physician';
  severity?: Severity;
}

export interface OrganFinding {
  organ: OrganKey;
  system: BodySystem;
  region: string;
  status: 'stable' | 'monitor' | 'elevated' | 'critical';
  evidence: string[];
  aiInsight: string;
  labs?: { name: string; value: string; flag?: 'up' | 'down' }[];
}

export interface VentilatorData {
  status: 'active' | 'standby' | 'off';
  mode: string;
  fio2: number;
  peep: number;
  tidalVolume: number;
  peakPressure: number;
  meanAirwayPressure: number;
  respiratoryRate: number;
}

export interface ClinicalFinding {
  id: string;
  finding: string;
  system: BodySystem;
  organ: OrganKey;
  region: string;
  severity: 'high' | 'moderate' | 'low';
  evidence: string[];
  aiInsight: string;
}

export interface RiskFactor {
  factor: string;
  weight: number;
}

export interface AICopilotAlert {
  priority: 'high' | 'medium' | 'low';
  patientId: string;
  patientName: string;
  reason: string[];
  system: BodySystem;
  riskScore: number;
  recommendation: string;
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  sex: 'M' | 'F';
  bed: string;
  status: Severity;
  diagnosis: string;
  deteriorationRisk: number;
  sepsisRisk: number;
  admissionDate: string;
  attendingPhysician: string;
  nurse: string;
  vitals: Vital[];
  labs: LabValue[];
  medications: Medication[];
  findings: ClinicalFinding[];
  organFindings: OrganFinding[];
  ventilator: VentilatorData | null;
  timeline: ClinicalEvent[];
  riskFactors: RiskFactor[];
  imaging: { type: string; study: string; finding: string | null }[];
}

export interface Bed {
  id: string;
  label: string;
  patientId: string | null;
  status: 'occupied' | 'available' | 'cleaning' | 'isolation';
  patientStatus: Severity | null;
  x: number;
  y: number;
  zone: string;
}

export interface AlertItem {
  id: string;
  patientName: string;
  bed: string;
  time: string;
  severity: Severity;
  trigger: string;
  aiConfidence: number;
  assignedClinician: string;
  status: 'active' | 'acknowledged' | 'resolved';
  category: 'vitals' | 'ai' | 'ventilator' | 'medication' | 'lab';
}

export interface CareTeamMember {
  id: string;
  name: string;
  role: string;
  status: 'online' | 'busy' | 'offline';
  patients: string[];
  shift: string;
}
