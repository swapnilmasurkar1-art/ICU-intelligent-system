import { Sparkles, AlertTriangle, ChevronRight, Brain } from 'lucide-react';
import type { Patient } from '@/types';
import { cn } from '@/lib/utils';

export function AIClinicalCopilot({ patient, compact }: { patient: Patient; compact?: boolean }) {
  const isCritical = patient.deteriorationRisk >= 80;
  const isWarning = patient.deteriorationRisk >= 50 && patient.deteriorationRisk < 80;

  return (
    <div className="glass-panel rounded-2xl p-4 h-full flex flex-col">
      <div className="flex items-center gap-2.5 mb-3 pb-3 border-b border-purple-500/15">
        <div className="relative">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
            <Sparkles className="h-4.5 w-4.5 text-white" />
          </div>
          <div className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-green-400 border-2 border-navy-850 animate-pulse" />
        </div>
        <div>
          <h3 className="text-sm font-bold gradient-text-ai">SwiftCare AI</h3>
          <p className="text-[10px] text-slate-500">Clinical Intelligence Copilot</p>
        </div>
      </div>

      <div className="mb-3">
        <p className="text-xs text-slate-400 mb-1.5">What needs attention?</p>
        <div className={cn(
          'p-3 rounded-xl border',
          isCritical ? 'bg-red-500/10 border-red-500/25' : isWarning ? 'bg-amber-500/10 border-amber-500/25' : 'bg-green-500/10 border-green-500/25'
        )}>
          <div className="flex items-center gap-2 mb-1.5">
            <AlertTriangle className={cn('h-4 w-4', isCritical ? 'text-red-400' : isWarning ? 'text-amber-400' : 'text-green-400')} />
            <span className={cn('text-[10px] font-bold uppercase tracking-wider', isCritical ? 'text-red-400' : isWarning ? 'text-amber-400' : 'text-green-400')}>
              {isCritical ? 'High Priority' : isWarning ? 'Monitor Closely' : 'Stable'}
            </span>
          </div>
          <p className="text-sm font-semibold text-white">{patient.name}</p>
          <p className="text-[11px] text-slate-400 mt-0.5">
            Deterioration risk: <span className="font-bold" style={{ color: isCritical ? '#ef4444' : isWarning ? '#f59e0b' : '#22c55e' }}>{patient.deteriorationRisk}%</span>
          </p>
        </div>
      </div>

      {!compact && patient.findings.length > 0 && (
        <div className="flex-1 overflow-y-auto space-y-3 scrollbar-hide">
          {patient.findings.map((finding) => (
            <div key={finding.id} className="p-3 rounded-xl bg-white/5 border border-white/5">
              <div className="flex items-center gap-2 mb-2">
                <Brain className="h-3.5 w-3.5 text-purple-400 shrink-0" />
                <span className="text-xs font-semibold text-white">{finding.finding}</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed mb-2">{finding.aiInsight}</p>
              <div className="space-y-1">
                <p className="text-[9px] text-slate-600 uppercase tracking-wider font-semibold">Evidence</p>
                {finding.evidence.map((ev, i) => (
                  <div key={i} className="flex items-center gap-1.5 text-[10px] text-slate-400">
                    <ChevronRight className="h-2.5 w-2.5 text-cyan-500/50" />
                    {ev}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="mt-3 pt-3 border-t border-white/5">
        <p className="text-[9px] text-slate-600 leading-relaxed">
          AI output is decision support, not autonomous diagnosis. Always correlate with clinical judgment.
        </p>
      </div>
    </div>
  );
}
