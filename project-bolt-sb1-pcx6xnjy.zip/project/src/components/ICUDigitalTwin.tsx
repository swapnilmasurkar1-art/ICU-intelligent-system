import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html, RoundedBox } from '@react-three/drei';
import { useRef, useState } from 'react';
import * as THREE from 'three';
import type { Bed, Patient } from '@/types';
import { cn } from '@/lib/utils';

const bedStatusColor: Record<string, string> = {
  stable: '#22c55e', warning: '#f59e0b', critical: '#ef4444', observation: '#3b82f6',
};

function Bed3D({ bed, patient, onClick, isSelected }: { bed: Bed; patient?: Patient; onClick: () => void; isSelected: boolean }) {
  const meshRef = useRef<THREE.Group>(null);
  const color = patient ? bedStatusColor[patient.status] : bed.status === 'cleaning' ? '#64748b' : '#1e2d52';

  useFrame((state) => {
    if (meshRef.current && patient?.status === 'critical') {
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 3) * 0.03;
      meshRef.current.scale.set(pulse, 1, pulse);
    }
  });

  return (
    <group ref={meshRef} position={[(bed.x - 45) / 8, 0, (bed.y - 50) / 8]} onClick={onClick}>
      {/* Bed base */}
      <RoundedBox args={[1.2, 0.3, 2]} radius={0.08} smoothness={4} position={[0, 0, 0]}>
        <meshStandardMaterial color="#1a2540" roughness={0.6} />
      </RoundedBox>

      {/* Patient indicator */}
      {patient && (
        <mesh position={[0, 0.4, 0]}>
          <capsuleGeometry args={[0.25, 1.2, 8, 16]} />
          <meshStandardMaterial
            color={color}
            emissive={new THREE.Color(color)}
            emissiveIntensity={patient.status === 'critical' ? 0.5 : 0.3}
            transparent
            opacity={0.85}
          />
        </mesh>
      )}

      {/* Glow ring for critical */}
      {patient?.status === 'critical' && (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.16, 0]}>
          <ringGeometry args={[0.7, 0.85, 32]} />
          <meshBasicMaterial color={color} transparent opacity={0.3} side={THREE.DoubleSide} />
        </mesh>
      )}

      {/* Label */}
      <Html position={[0, patient ? 1.2 : 0.4, 0]} center distanceFactor={8}>
        <div className={cn(
          'px-2 py-0.5 rounded-md whitespace-nowrap pointer-events-none transition-all',
          isSelected ? 'glass-strong border border-cyan-500/40' : 'glass border border-white/10'
        )}>
          <p className="text-[9px] font-bold text-white">{bed.label}</p>
          {patient && (
            <p className="text-[7px] uppercase tracking-wider" style={{ color }}>{patient.status}</p>
          )}
        </div>
      </Html>
    </group>
  );
}

function NurseStation({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <RoundedBox args={[1.5, 0.5, 1]} radius={0.06} smoothness={4}>
        <meshStandardMaterial color="#0f1a33" roughness={0.5} metalness={0.2} />
      </RoundedBox>
      <mesh position={[0, 0.4, 0]}>
        <cylinderGeometry args={[0.15, 0.15, 0.3, 8]} />
        <meshStandardMaterial color="#22d3ee" emissive="#22d3ee" emissiveIntensity={0.3} />
      </mesh>
      <Html position={[0, 0.7, 0]} center distanceFactor={8}>
        <div className="px-1.5 py-0.5 rounded glass text-[8px] text-cyan-300 font-bold pointer-events-none whitespace-nowrap">
          NURSE STATION
        </div>
      </Html>
    </group>
  );
}

interface ICUDigitalTwinProps {
  beds: Bed[];
  patients: Patient[];
  onBedClick?: (bed: Bed) => void;
}

export function ICUDigitalTwin({ beds, patients, onBedClick }: ICUDigitalTwinProps) {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="relative w-full h-full">
      <Canvas camera={{ position: [0, 6, 8], fov: 50 }} dpr={[1, 2]}>
        <ambientLight intensity={0.35} />
        <pointLight position={[5, 8, 5]} intensity={0.6} color="#22d3ee" />
        <pointLight position={[-5, 5, -5]} intensity={0.3} color="#a855f7" />

        {/* Floor grid */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.2, 0]}>
          <planeGeometry args={[20, 20]} />
          <meshStandardMaterial color="#0a1020" roughness={0.9} metalness={0.1} />
        </mesh>
        <gridHelper args={[20, 20, '#16213f', '#0d1428']} position={[0, -0.19, 0]} />

        {/* Nurse stations */}
        <NurseStation position={[-3, 0, 0]} />
        <NurseStation position={[3, 0, 0]} />

        {/* Beds */}
        {beds.map((bed) => {
          const patient = bed.patientId ? patients.find((p) => p.id === bed.patientId) : undefined;
          return (
            <Bed3D
              key={bed.id}
              bed={bed}
              patient={patient}
              isSelected={selected === bed.id}
              onClick={() => {
                setSelected(bed.id);
                onBedClick?.(bed);
              }}
            />
          );
        })}

        <OrbitControls
          enablePan={false}
          minDistance={5}
          maxDistance={15}
          minPolarAngle={Math.PI / 6}
          maxPolarAngle={Math.PI / 2.2}
        />
      </Canvas>

      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-[10px] text-slate-500 glass px-3 py-1 rounded-full">
        Drag to rotate · Scroll to zoom · Click bed for patient
      </div>
    </div>
  );
}
