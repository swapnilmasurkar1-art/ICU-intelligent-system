import { useState } from 'react';
import { cn } from '@/lib/utils';
import type { ClinicalEvent } from '@/types';
import {
  AlertTriangle, Activity, FlaskConical, Sparkles, Stethoscope, Pill, Heart,
} from 'lucide-react';

const typeConfig: Record<ClinicalEvent['type'], { icon: typeof AlertTriangle; color: string; bg: string }> = {
  alert: { icon: AlertTriangle, color: 'text-red-400', bg: 'bg-red-500/15' },
  vital: { icon: Heart, color: 'text-amber-400', bg: 'bg-amber-500/15' },
  lab: { icon: FlaskConical, color: 'text-blue-400', bg: 'bg-blue-500/15' },
  ai: { icon: Sparkles, color: 'text-purple-400', bg: 'bg-purple-500/15' },
  intervention: { icon: Activity, color: 'text-cyan-400', bg: 'bg-cyan-500/15' },
  nursing: { icon: Stethoscope, color: 'text-teal-400', bg: 'bg-teal-500/15' },
  physician: { icon: Stethoscope, color: 'text-green-400', bg: 'bg-green-500/15' },
};

export function ClinicalTimeline({ events, onSelect }: { events: ClinicalEvent[]; onSelect?: (e: ClinicalEvent) => void }) {
  const [selected, setSelected] = useState<ClinicalEvent | null>(null);

  return (
    <div className="glass-panel rounded-2xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-bold text-white">Clinical Timeline</h3>
        <span className="text-[10px] text-slate-500">{events.length} events</span>
      </div>

      <div className="overflow-x-auto scrollbar-hide">
        <div className="relative min-w-full pb-2">
          <div className="absolute top-[22px] left-0 right-0 h-0.5 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-cyan-500/20" />
          <div className="flex gap-0 relative">
            {events.map((event, i) => {
              const cfg = typeConfig[event.type];
              const Icon = cfg.icon;
              const isSelected = selected?.time === event.time;
              return (
                <div key={i} className="flex flex-col items-center" style={{ flex: '0 0 120px' }}>
                  <button
                    onClick={() => { setSelected(event); onSelect?.(event); }}
                    className={cn(
                      'relative h-11 w-11 rounded-full flex items-center justify-center transition-all hover:scale-110 z-10 border-2',
                      cfg.bg, cfg.color,
                      isSelected ? 'border-white/30 scale-110' : 'border-transparent'
                    )}
                  >
                    <Icon className="h-4 w-4" />
                    {event.severity === 'critical' && (
                      <span className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-red-500 animate-pulse" />
                    )}
                  </button>
                  <span className="text-[10px] font-semibold text-slate-300 mt-1.5">{event.time}</span>
                  <span className="text-[9px] text-slate-500 text-center mt-0.5 leading-tight">{event.title}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {selected && (
        <div className="mt-4 p-3 rounded-xl bg-white/5 border border-cyan-500/10 animate-slide-up">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-white">{selected.time}</span>
            <span className={cn('text-[10px] uppercase tracking-wider font-semibold', typeConfig[selected.type].color)}>
              {selected.type}
            </span>
          </div>
          <p className="text-sm font-semibold text-white">{selected.title}</p>
          <p className="text-xs text-slate-400 mt-1">{selected.description}</p>
        </div>
      )}
    </div>
  );
}
