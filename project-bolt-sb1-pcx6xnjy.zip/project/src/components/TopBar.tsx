import { useState } from 'react';
import { Menu, Search, Bell, Siren, Sparkles, Moon, Sun, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TopBarProps {
  onToggleSidebar: () => void;
  breadcrumbs: string[];
  darkMode: boolean;
  onToggleDarkMode: () => void;
  onNavigate: (page: string) => void;
}

export function TopBar({ onToggleSidebar, breadcrumbs, darkMode, onToggleDarkMode, onNavigate }: TopBarProps) {
  const [notifOpen, setNotifOpen] = useState(false);

  return (
    <header className="sticky top-0 z-30 h-16 glass-strong border-b border-cyan-500/10 flex items-center justify-between px-4 lg:px-6 gap-4">
      {/* Left: Menu + Breadcrumb */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onToggleSidebar}
          className="lg:hidden p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-white/5 transition-colors"
        >
          <Menu className="h-5 w-5" />
        </button>

        <div className="flex items-center gap-2 text-sm min-w-0">
          <span className="font-bold text-white hidden sm:inline">SwiftCare AI</span>
          {breadcrumbs.map((crumb, i) => (
            <div key={i} className="flex items-center gap-2 min-w-0">
              <ChevronRight className="h-3.5 w-3.5 text-slate-600 shrink-0" />
              <span className={cn(
                'truncate',
                i === breadcrumbs.length - 1 ? 'text-cyan-300 font-medium' : 'text-slate-500'
              )}>
                {crumb}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Center: Live Status */}
      <div className="hidden md:flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-green-500/10 border border-green-500/20">
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75 animate-ping" />
          <span className="relative inline-flex rounded-full h-2 w-2 bg-green-400" />
        </span>
        <span className="text-xs font-semibold text-green-300 tracking-wide">LIVE ICU MONITORING</span>
        <span className="text-[10px] text-green-400/60">Synced 2s ago</span>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        <button className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-white/5 transition-colors">
          <Search className="h-[18px] w-[18px]" />
        </button>

        <div className="relative">
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-white/5 transition-colors relative"
          >
            <Bell className="h-[18px] w-[18px]" />
            <span className="absolute top-1 right-1 h-2 w-2 rounded-full bg-red-500 animate-pulse" />
          </button>
          {notifOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setNotifOpen(false)} />
              <div className="absolute right-0 top-full mt-2 w-80 glass-strong rounded-2xl border border-cyan-500/15 p-3 z-50 animate-slide-up">
                <h4 className="text-xs font-bold text-white mb-2 px-1">Notifications</h4>
                <div className="space-y-1.5 max-h-72 overflow-y-auto">
                  {[
                    { sev: 'critical', title: 'SpO2 below threshold', patient: 'Sunita Verma — ICU-03', time: '2 min ago' },
                    { sev: 'warning', title: 'AI deterioration alert', patient: 'Rajesh Kumar — ICU-07', time: '8 min ago' },
                    { sev: 'warning', title: 'Creatinine rising', patient: 'Sunita Verma — ICU-03', time: '15 min ago' },
                  ].map((n, i) => (
                    <div key={i} className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors cursor-pointer">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn('h-1.5 w-1.5 rounded-full', n.sev === 'critical' ? 'bg-red-400' : 'bg-amber-400')} />
                        <span className="text-xs font-semibold text-white">{n.title}</span>
                      </div>
                      <p className="text-[11px] text-slate-400 pl-3.5">{n.patient}</p>
                      <p className="text-[10px] text-slate-600 pl-3.5 mt-0.5">{n.time}</p>
                    </div>
                  ))}
                </div>
                <button onClick={() => { onNavigate('alerts'); setNotifOpen(false); }} className="w-full mt-2 py-2 text-xs text-cyan-400 hover:text-cyan-300 font-medium">
                  View All Alerts
                </button>
              </div>
            </>
          )}
        </div>

        <button className="p-2 rounded-lg text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors">
          <Siren className="h-[18px] w-[18px]" />
        </button>

        <button
          onClick={() => onNavigate('ai-copilot')}
          className="p-2 rounded-lg text-purple-400 hover:text-purple-300 hover:bg-purple-500/10 transition-colors"
        >
          <Sparkles className="h-[18px] w-[18px]" />
        </button>

        <button onClick={onToggleDarkMode} className="p-2 rounded-lg text-slate-400 hover:text-cyan-400 hover:bg-white/5 transition-colors">
          {darkMode ? <Moon className="h-[18px] w-[18px]" /> : <Sun className="h-[18px] w-[18px]" />}
        </button>

        <div className="hidden sm:flex items-center gap-2.5 pl-2 ml-1 border-l border-cyan-500/10">
          <div className="text-right">
            <p className="text-xs font-semibold text-white leading-tight">Dr. Sanjay Mehta</p>
            <p className="text-[10px] text-slate-500">Attending Physician</p>
          </div>
          <div className="h-8 w-8 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-xs font-bold text-navy-950">
            SM
          </div>
        </div>
      </div>
    </header>
  );
}
