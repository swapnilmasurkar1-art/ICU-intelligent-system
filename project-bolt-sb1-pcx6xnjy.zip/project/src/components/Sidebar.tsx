import { useState } from 'react';
import { ChevronLeft, ChevronRight, Activity } from 'lucide-react';
import { navSections, mobileNav } from '@/config/nav';
import { cn } from '@/lib/utils';

interface SidebarProps {
  activePage: string;
  onNavigate: (page: string) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
}

export function Sidebar({ activePage, onNavigate, collapsed, onToggleCollapse }: SidebarProps) {
  return (
    <aside
      className={cn(
        'fixed left-0 top-0 z-40 h-screen glass-strong border-r border-cyan-500/10 transition-all duration-300 hidden lg:flex flex-col',
        collapsed ? 'w-[68px]' : 'w-[260px]'
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-cyan-500/10 shrink-0">
        <div className="relative shrink-0">
          <div className="h-9 w-9 rounded-xl bg-gradient-to-br from-cyan-400 to-teal-500 flex items-center justify-center glow-cyan">
            <Activity className="h-5 w-5 text-navy-950" strokeWidth={2.5} />
          </div>
          <div className="absolute -top-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-green-400 border-2 border-navy-900 animate-pulse" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-sm font-bold text-white tracking-tight leading-tight">SwiftCare AI</h1>
            <p className="text-[10px] text-cyan-400/70 uppercase tracking-widest font-medium">ICU Clinical Command</p>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto scrollbar-hide py-3">
        {navSections.map((section) => (
          <div key={section.title} className="mb-4">
            {!collapsed && (
              <p className="px-5 mb-1.5 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                {section.title}
              </p>
            )}
            {collapsed && (
              <div className="mx-4 mb-1.5 border-t border-cyan-500/10" />
            )}
            <div className="space-y-0.5 px-2">
              {section.items.map((item) => {
                const Icon = item.icon;
                const active = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onNavigate(item.id)}
                    className={cn(
                      'w-full flex items-center gap-3 rounded-lg transition-all duration-200 group relative',
                      collapsed ? 'justify-center px-2 py-2.5' : 'px-3 py-2',
                      active
                        ? 'bg-cyan-500/10 text-cyan-300'
                        : 'text-slate-400 hover:text-slate-200 hover:bg-white/5'
                    )}
                    title={collapsed ? item.label : undefined}
                  >
                    {active && (
                      <span className="absolute left-0 top-1/2 -translate-y-1/2 h-6 w-0.5 bg-cyan-400 rounded-r-full" />
                    )}
                    <Icon className={cn('h-[18px] w-[18px] shrink-0', active && 'drop-shadow-[0_0_4px_rgba(34,211,238,0.5)]')} />
                    {!collapsed && <span className="text-[13px] font-medium">{item.label}</span>}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Collapse Toggle */}
      <button
        onClick={onToggleCollapse}
        className="flex items-center justify-center gap-2 h-12 border-t border-cyan-500/10 text-slate-500 hover:text-cyan-400 transition-colors shrink-0"
      >
        {collapsed ? <ChevronRight className="h-4 w-4" /> : <><ChevronLeft className="h-4 w-4" /> <span className="text-xs">Collapse</span></>}
      </button>
    </aside>
  );
}

export function MobileNav({ activePage, onNavigate }: { activePage: string; onNavigate: (p: string) => void }) {
  const [moreOpen, setMoreOpen] = useState(false);
  const mobileItems = mobileNav;

  return (
    <>
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-40 glass-strong border-t border-cyan-500/15 px-2 py-1.5 flex items-center justify-around">
        {mobileItems.map((item: any) => {
          const Icon = item.icon;
          const active = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                'flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg transition-colors',
                active ? 'text-cyan-400' : 'text-slate-500'
              )}
            >
              <Icon className="h-5 w-5" />
              <span className="text-[10px] font-medium">{item.label}</span>
            </button>
          );
        })}
        <button
          onClick={() => setMoreOpen(true)}
          className="flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-slate-500"
        >
          <ChevronRight className="h-5 w-5" />
          <span className="text-[10px] font-medium">More</span>
        </button>
      </nav>

      {moreOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-navy-950/80 backdrop-blur-sm" onClick={() => setMoreOpen(false)}>
          <div className="absolute bottom-0 left-0 right-0 glass-strong rounded-t-3xl p-5 max-h-[70vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-slate-600 rounded-full mx-auto mb-4" />
            <h3 className="text-sm font-bold text-white mb-3">All Navigation</h3>
            <div className="grid grid-cols-2 gap-2">
              {navSections.flatMap(s => s.items).map(item => {
                const Icon = item.icon;
                const active = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => { onNavigate(item.id); setMoreOpen(false); }}
                    className={cn(
                      'flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-[13px] font-medium transition-colors',
                      active ? 'bg-cyan-500/10 text-cyan-300' : 'bg-white/5 text-slate-400'
                    )}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span className="truncate">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
