import { useRef, useState, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls, Html, Float } from '@react-three/drei';
import * as THREE from 'three';
import type { OrganKey, OrganFinding } from '@/types';
import { cn } from '@/lib/utils';

const organStatusColor: Record<string, string> = {
  stable: '#22c55e',
  monitor: '#3b82f6',
  elevated: '#f59e0b',
  critical: '#ef4444',
};

interface OrganProps {
  position: [number, number, number];
  scale?: [number, number, number];
  organKey: OrganKey;
  label: string;
  finding?: OrganFinding;
  onClick: (organ: OrganKey) => void;
  isSelected: boolean;
  isHighlighted: boolean;
}

function Organ({ position, scale = [1, 1, 1], organKey, label, finding, onClick, isSelected, isHighlighted }: OrganProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const status = finding?.status || 'stable';
  const color = isSelected || isHighlighted ? organStatusColor[status] : '#4a5568';
  const hasIssue = finding && status !== 'stable';

  useFrame((state) => {
    if (!meshRef.current) return;
    if (hasIssue || isSelected) {
      const pulse = 1 + Math.sin(state.clock.elapsedTime * 2) * 0.05;
      meshRef.current.scale.set(scale[0] * pulse, scale[1] * pulse, scale[2] * pulse);
    } else {
      meshRef.current.scale.set(...scale);
    }
  });

  const geometry = useMemo(() => {
    switch (organKey) {
      case 'brain': return <sphereGeometry args={[0.55, 24, 24]} />;
      case 'heart': return <sphereGeometry args={[0.42, 20, 20]} />;
      case 'lungs': return <sphereGeometry args={[0.5, 16, 16]} />;
      case 'liver': return <sphereGeometry args={[0.55, 16, 16]} />;
      case 'kidneys': return <capsuleGeometry args={[0.22, 0.3, 8, 16]} />;
      case 'gastrointestinal': return <capsuleGeometry args={[0.3, 0.8, 8, 16]} />;
      case 'vascular': return <cylinderGeometry args={[0.12, 0.12, 2.5, 12]} />;
      case 'skeletal': return <capsuleGeometry args={[0.08, 1.8, 6, 12]} />;
      default: return <sphereGeometry args={[0.4, 16, 16]} />;
    }
  }, [organKey]);

  return (
    <group position={position}>
      <mesh
        ref={meshRef}
        onClick={(e) => { e.stopPropagation(); onClick(organKey); }}
        onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = 'pointer'; }}
        onPointerOut={() => { document.body.style.cursor = 'default'; }}
      >
        {geometry}
        <meshStandardMaterial
          color={color}
          emissive={hasIssue || isSelected ? new THREE.Color(organStatusColor[status]) : new THREE.Color('#000')}
          emissiveIntensity={hasIssue || isSelected ? 0.35 : 0}
          transparent
          opacity={isSelected ? 0.95 : isHighlighted ? 0.85 : 0.55}
          roughness={0.4}
          metalness={0.1}
        />
      </mesh>
      {hasIssue && (
        <mesh scale={scale.map(s => s * 1.8) as [number, number, number]}>
          {geometry}
          <meshBasicMaterial
            color={organStatusColor[status]}
            transparent
            opacity={0.12}
            side={THREE.BackSide}
          />
        </mesh>
      )}
      {(isSelected || isHighlighted) && (
        <Html position={[0, 0.5, 0]} center distanceFactor={6}>
          <div className="px-2 py-1 rounded-lg glass-strong border border-cyan-500/30 whitespace-nowrap pointer-events-none">
            <p className="text-[10px] font-bold text-white">{label}</p>
            {finding && (
              <p className="text-[8px] uppercase tracking-wider" style={{ color: organStatusColor[status] }}>
                {status}
              </p>
            )}
          </div>
        </Html>
      )}
    </group>
  );
}

function HumanBody({
  organFindings,
  selectedOrgan,
  onOrganClick,
  activeSystem,
}: {
  organFindings: OrganFinding[];
  selectedOrgan: OrganKey | null;
  onOrganClick: (o: OrganKey) => void;
  activeSystem: string | null;
}) {
  const bodyRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (bodyRef.current && !selectedOrgan) {
      bodyRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.15) * 0.15;
    }
  });

  const organPositions: Record<OrganKey, { pos: [number, number, number]; scale: [number, number, number]; label: string }> = {
    brain: { pos: [0, 3.0, 0], scale: [1, 1, 1], label: 'BRAIN' },
    heart: { pos: [0.35, 1.6, 0.3], scale: [1, 1, 1], label: 'HEART' },
    lungs: { pos: [0, 1.7, 0], scale: [1.4, 1.2, 0.8], label: 'LUNGS' },
    liver: { pos: [0.3, 0.5, 0.2], scale: [1.2, 0.8, 0.8], label: 'LIVER' },
    kidneys: { pos: [-0.3, 0.3, -0.3], scale: [1, 1, 1], label: 'KIDNEYS' },
    gastrointestinal: { pos: [0, -0.3, 0.2], scale: [1, 1, 1], label: 'GI TRACT' },
    vascular: { pos: [0, 1.0, 0], scale: [1, 1, 1], label: 'VASCULAR' },
    skeletal: { pos: [0, 0.5, -0.2], scale: [1, 1, 1], label: 'SKELETAL' },
  };

  const systemToOrgans: Record<string, OrganKey[]> = {
    neurological: ['brain'],
    cardiovascular: ['heart', 'vascular'],
    respiratory: ['lungs'],
    renal: ['kidneys'],
    hepatic: ['liver', 'gastrointestinal'],
    musculoskeletal: ['skeletal'],
    hematological: ['vascular'],
    infectious: ['vascular'],
  };

  const highlightOrgans = activeSystem ? systemToOrgans[activeSystem] || [] : [];

  return (
    <group ref={bodyRef}>
      {/* Body silhouette */}
      <mesh position={[0, 1.2, 0]}>
        <capsuleGeometry args={[0.85, 2.2, 8, 24]} />
        <meshStandardMaterial
          color="#1e2d52"
          transparent
          opacity={0.15}
          roughness={0.8}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* Head */}
      <mesh position={[0, 3.0, 0]}>
        <sphereGeometry args={[0.7, 24, 24]} />
        <meshStandardMaterial color="#1e2d52" transparent opacity={0.12} roughness={0.8} />
      </mesh>

      {/* Organs */}
      {(Object.keys(organPositions) as OrganKey[]).map((key) => {
        const config = organPositions[key];
        const finding = organFindings.find((f) => f.organ === key);
        const isHighlighted = highlightOrgans.includes(key) || (!!finding && finding.status !== 'stable');
        return (
          <Organ
            key={key}
            position={config.pos}
            scale={config.scale}
            organKey={key}
            label={config.label}
            finding={finding}
            onClick={onOrganClick}
            isSelected={selectedOrgan === key}
            isHighlighted={isHighlighted}
          />
        );
      })}
    </group>
  );
}

const systemControls = [
  { id: null, label: 'Full Body' },
  { id: 'neurological', label: 'Neurological' },
  { id: 'cardiovascular', label: 'Cardiovascular' },
  { id: 'respiratory', label: 'Respiratory' },
  { id: 'renal', label: 'Renal' },
  { id: 'hepatic', label: 'Hepatic' },
  { id: 'musculoskeletal', label: 'Musculoskeletal' },
];

interface HumanBody3DProps {
  organFindings: OrganFinding[];
  onOrganSelect?: (organ: OrganKey) => void;
}

export function HumanBody3D({ organFindings, onOrganSelect }: HumanBody3DProps) {
  const [selected, setSelected] = useState<OrganKey | null>(null);
  const [activeSystem, setActiveSystem] = useState<string | null>(null);

  const handleOrganClick = (organ: OrganKey) => {
    setSelected(organ);
    onOrganSelect?.(organ);
  };

  return (
    <div className="relative w-full h-full">
      <Canvas camera={{ position: [0, 1, 7], fov: 45 }} dpr={[1, 2]}>
        <ambientLight intensity={0.4} />
        <pointLight position={[5, 5, 5]} intensity={0.6} color="#22d3ee" />
        <pointLight position={[-5, 3, -5]} intensity={0.4} color="#a855f7" />
        <spotLight position={[0, 8, 0]} intensity={0.5} angle={0.5} penumbra={1} color="#ffffff" />
        <HumanBody
          organFindings={organFindings}
          selectedOrgan={selected}
          onOrganClick={handleOrganClick}
          activeSystem={activeSystem}
        />
        <OrbitControls
          enablePan={true}
          enableZoom={true}
          minDistance={3}
          maxDistance={12}
          target={[0, 1.2, 0]}
        />
      </Canvas>

      {/* System Controls */}
      <div className="absolute top-3 left-3 flex flex-col gap-1.5 max-w-[140px]">
        {systemControls.map((sys) => (
          <button
            key={sys.label}
            onClick={() => setActiveSystem(sys.id)}
            className={cn(
              'px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all text-left',
              activeSystem === sys.id
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                : 'glass text-slate-400 hover:text-white border border-transparent'
            )}
          >
            {sys.label}
          </button>
        ))}
      </div>

      {/* Instructions */}
      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-[10px] text-slate-500 glass px-3 py-1 rounded-full">
        Drag to rotate · Scroll to zoom · Click organ for details
      </div>

      {selected && (
        <button
          onClick={() => setSelected(null)}
          className="absolute top-3 right-3 px-3 py-1.5 rounded-lg glass text-[11px] text-cyan-300 hover:bg-cyan-500/10 transition-colors font-medium"
        >
          Reset View
        </button>
      )}
    </div>
  );
}
