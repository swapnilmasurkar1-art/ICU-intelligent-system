import { useState } from 'react';
import type { OrganFinding, OrganKey } from '@/types';
import { cn } from '@/lib/utils';
import { X, ArrowUp, ArrowDown, Activity, TrendingUp, Sparkles, FlaskConical } from 'lucide-react';

const organStatusConfig: Record<string, { color: string; bg: string; label: string }> = {
  stable: { color: '#22c55e', bg: 'bg-green-500/15', label: 'STABLE' },
  monitor: { color: '#3b82f6', bg: 'bg-blue-500/15', label: 'MONITOR' },
  elevated: { color: '#f59e0b', bg: 'bg-amber-500/15', label: 'ELEVATED' },
  critical: { color: '#ef4444', bg: 'bg-red-500/15', label: 'CRITICAL' },
};

const organLabels: Record<OrganKey, string> = {
  brain: 'Brain', heart: 'Heart', lungs: 'Lungs', liver: 'Liver',
  kidneys: 'Kidneys', gastrointestinal: 'GI Tract', vascular: 'Vascular', skeletal: 'Skeletal',
};

export function OrganRiskMap({ findings, onOrganClick }: { findings: OrganFinding[]; onOrganClick?: (o: OrganKey) => void }) {
  const organs: OrganKey[] = ['brain', 'heart', 'lungs', 'liver', 'kidneys'];

  return (
    <div className="glass-panel rounded-2xl p-4">
      <h3 className="text-sm font-bold text-white mb-3">Organ Risk Map</h3>
      <div className="space-y-2">
        {organs.map((organ) => {
          const finding = findings.find((f) => f.organ === organ);
          const status = finding?.status || 'stable';
          const cfg = organStatusConfig[status];
          return (
            <button
              key={organ}
              onClick={() => onOrganClick?.(organ)}
              className="w-full flex items-center justify-between p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-all group"
            >
              <div className="flex items-center gap-2.5">
                <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: cfg.color, boxShadow: `0 0 6px ${cfg.color}80` }} />
                <span className="text-xs font-medium text-white">{organLabels[organ]}</span>
              </div>
              <span className={cn('text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full', cfg.bg)} style={{ color: cfg.color }}>
                {cfg.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

export function OrganDetailPanel({ finding, onClose }: { finding: OrganFinding; onClose: () => void }) {
  const cfg = organStatusConfig[finding.status];

  return (
    <div className="glass-strong rounded-2xl p-5 border-cyan-500/20 animate-slide-right">
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="text-lg font-bold text-white">{organLabels[finding.organ]}</h3>
          <p className="text-xs text-slate-400">{finding.region}</p>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg text-slate-500 hover:text-white hover:bg-white/10 transition-colors">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className={cn('inline-flex items-center gap-2 px-3 py-1 rounded-full mb-4', cfg.bg)}>
        <span className="h-2 w-2 rounded-full animate-pulse" style={{ backgroundColor: cfg.color }} />
        <span className="text-xs font-bold uppercase tracking-wider" style={{ color: cfg.color }}>
          {finding.status === 'elevated' ? 'HIGH RISK' : finding.status === 'critical' ? 'CRITICAL' : finding.status.toUpperCase()}
        </span>
      </div>

      {finding.labs && finding.labs.length > 0 && (
        <div className="space-y-1.5 mb-4">
          <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Clinical Values</p>
          {finding.labs.map((lab, i) => (
            <div key={i} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
              <span className="text-xs text-slate-300">{lab.name}</span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-white">{lab.value}</span>
                {lab.flag === 'up' && <ArrowUp className="h-3 w-3 text-red-400" />}
                {lab.flag === 'down' && <ArrowDown className="h-3 w-3 text-amber-400" />}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="space-y-1.5 mb-4">
        <p className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Evidence</p>
        {finding.evidence.map((ev, i) => (
          <div key={i} className="flex items-center gap-2 text-xs text-slate-300">
            <span className="h-1 w-1 rounded-full bg-cyan-400" />
            {ev}
          </div>
        ))}
      </div>

      <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 mb-4">
        <div className="flex items-center gap-2 mb-1.5">
          <Sparkles className="h-3.5 w-3.5 text-purple-400" />
          <span className="text-[10px] font-bold uppercase tracking-wider text-purple-300">AI Assessment</span>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">{finding.aiInsight}</p>
      </div>

      <div className="flex gap-2">
        <button className="flex-1 py-2 rounded-lg bg-cyan-500/10 text-cyan-300 text-xs font-semibold hover:bg-cyan-500/20 transition-colors flex items-center justify-center gap-1.5">
          <FlaskConical className="h-3.5 w-3.5" /> View Labs
        </button>
        <button className="flex-1 py-2 rounded-lg bg-white/5 text-slate-300 text-xs font-semibold hover:bg-white/10 transition-colors flex items-center justify-center gap-1.5">
          <TrendingUp className="h-3.5 w-3.5" /> View Trend
        </button>
        <button className="flex-1 py-2 rounded-lg bg-purple-500/10 text-purple-300 text-xs font-semibold hover:bg-purple-500/20 transition-colors flex items-center justify-center gap-1.5">
          <Activity className="h-3.5 w-3.5" /> AI Explanation
        </button>
      </div>
    </div>
  );
}
