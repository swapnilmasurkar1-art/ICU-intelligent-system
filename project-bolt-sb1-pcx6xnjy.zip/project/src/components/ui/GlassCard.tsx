import React from 'react';
import { cn } from '@/lib/utils';
import type { Severity } from '@/types';

const severityConfig: Record<Severity, { color: string; bg: string; text: string; border: string; label: string; glow: string }> = {
  critical: { color: '#ef4444', bg: 'bg-red-500/15', text: 'text-red-400', border: 'border-red-500/30', label: 'CRITICAL', glow: 'glow-critical' },
  warning: { color: '#f59e0b', bg: 'bg-amber-500/15', text: 'text-amber-400', border: 'border-amber-500/30', label: 'WARNING', glow: 'glow-warning' },
  stable: { color: '#22c55e', bg: 'bg-green-500/15', text: 'text-green-400', border: 'border-green-500/30', label: 'STABLE', glow: '' },
  observation: { color: '#3b82f6', bg: 'bg-blue-500/15', text: 'text-blue-400', border: 'border-blue-500/30', label: 'OBSERVATION', glow: '' },
};

export function SeverityBadge({ severity, size = 'sm' }: { severity: Severity; size?: 'sm' | 'xs' }) {
  const cfg = severityConfig[severity];
  return (
    <span className={cn(
      'inline-flex items-center gap-1.5 rounded-full border font-semibold uppercase tracking-wider',
      cfg.bg, cfg.text, cfg.border,
      size === 'sm' ? 'px-2.5 py-0.5 text-[10px]' : 'px-2 py-0.5 text-[9px]'
    )}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: cfg.color }} />
      {cfg.label}
    </span>
  );
}

export function getSeverityConfig(severity: Severity) {
  return severityConfig[severity];
}

export function GlassCard({ children, className, glow }: { children: React.ReactNode; className?: string; glow?: string }) {
  return (
    <div className={cn('glass-panel rounded-2xl', glow, className)}>
      {children}
    </div>
  );
}

export function AnimatedNumber({ value, suffix = '', duration = 1500 }: { value: number; suffix?: string; duration?: number }) {
  const [display, setDisplay] = React.useState(0);
  React.useEffect(() => {
    let start = 0;
    const startTime = Date.now();
    const tick = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(Math.round(start + (value - start) * eased));
      if (progress < 1) requestAnimationFrame(tick);
    };
    tick();
  }, [value, duration]);
  return <span>{display}{suffix}</span>;
}
