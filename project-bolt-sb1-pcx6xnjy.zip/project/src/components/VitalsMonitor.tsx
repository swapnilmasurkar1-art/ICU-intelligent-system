import { LineChart, Line, ResponsiveContainer, YAxis, ReferenceLine, AreaChart, Area } from 'recharts';
import type { Vital } from '@/types';
import { cn } from '@/lib/utils';
import { Heart, Activity, Wind, Thermometer, Lungs, TrendingUp, TrendingDown, Minus } from 'lucide-react';

const iconMap: Record<string, typeof Heart> = {
  heart: Heart, activity: Activity, wind: Wind, thermometer: Thermometer, lungs: Lungs,
};

const trendIcon = { up: TrendingUp, down: TrendingDown, stable: Minus };

export function TelemetryChart({ data, color, height = 40 }: { data: { time: string; value: number }[]; color: string; height?: number }) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 2, bottom: 2, left: 0, right: 0 }}>
        <defs>
          <linearGradient id={`grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.4} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={1.5}
          fill={`url(#grad-${color.replace('#', '')})`}
          isAnimationActive={true}
          animationDuration={800}
        />
      </AreaChart>
    </ResponsiveContainer>
  );
}

export function VitalCard({ vital }: { vital: Vital }) {
  const Icon = iconMap[vital.icon] || Heart;
  const TrendIcon = trendIcon[vital.trend];
  const isAbnormal = vital.value < vital.normalMin || vital.value > vital.normalMax;
  const color = isAbnormal ? '#ef4444' : '#22d3ee';
  const trendColor = vital.trend === 'up' ? 'text-red-400' : vital.trend === 'down' ? 'text-amber-400' : 'text-slate-400';

  return (
    <div className={cn(
      'glass-panel rounded-xl p-3.5 transition-all hover:scale-[1.02] hover:border-cyan-500/20',
      isAbnormal && 'border-red-500/20'
    )}>
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className={cn('p-1.5 rounded-lg', isAbnormal ? 'bg-red-500/15 text-red-400' : 'bg-cyan-500/15 text-cyan-400')}>
            <Icon className="h-3.5 w-3.5" />
          </div>
          <div>
            <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium">{vital.label}</p>
            <p className="text-[9px] text-slate-600">Normal: {vital.normalMin}–{vital.normalMax}</p>
          </div>
        </div>
        <div className={cn('flex items-center gap-0.5 text-[10px] font-semibold', trendColor)}>
          <TrendIcon className="h-3 w-3" />
          {Math.abs(vital.trendValue)}
        </div>
      </div>
      <div className="flex items-baseline gap-1 mb-1.5">
        <span className="text-2xl font-bold tabular-nums" style={{ color }}>{vital.value}</span>
        <span className="text-xs text-slate-500">{vital.unit}</span>
      </div>
      <TelemetryChart data={vital.history} color={color} height={32} />
    </div>
  );
}

export function VitalsGrid({ vitals, compact }: { vitals: Vital[]; compact?: boolean }) {
  return (
    <div className={cn('grid gap-3', compact ? 'grid-cols-2 md:grid-cols-3' : 'grid-cols-2 md:grid-cols-3 lg:grid-cols-5')}>
      {vitals.map((v) => <VitalCard key={v.key} vital={v} />)}
    </div>
  );
}

export function LargeTelemetryChart({ vital, height = 180 }: { vital: Vital; height?: number }) {
  const isAbnormal = vital.value < vital.normalMin || vital.value > vital.normalMax;
  const color = isAbnormal ? '#ef4444' : '#22d3ee';

  return (
    <div className="glass-panel rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-sm font-semibold text-white">{vital.label}</p>
          <p className="text-[10px] text-slate-500">Normal range: {vital.normalMin} – {vital.normalMax} {vital.unit}</p>
        </div>
        <div className="text-right">
          <span className="text-2xl font-bold tabular-nums" style={{ color }}>{vital.value}</span>
          <span className="text-xs text-slate-500 ml-1">{vital.unit}</span>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={vital.history} margin={{ top: 5, bottom: 5, left: 0, right: 5 }}>
          <YAxis hide domain={['dataMin - 5', 'dataMax + 5']} />
          <ReferenceLine y={vital.normalMin} stroke="#22c55e" strokeDasharray="3 3" strokeOpacity={0.3} />
          <ReferenceLine y={vital.normalMax} stroke="#22c55e" strokeDasharray="3 3" strokeOpacity={0.3} />
          {vital.alertThreshold && (
            <ReferenceLine y={vital.alertThreshold} stroke="#ef4444" strokeDasharray="3 3" strokeOpacity={0.4} />
          )}
          <Line
            type="monotone"
            dataKey="value"
            stroke={color}
            strokeWidth={2}
            dot={false}
            isAnimationActive={true}
            animationDuration={600}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
