import { cn } from '@/lib/utils';

export function RiskGauge({ value, label = 'Deterioration Risk', size = 120 }: { value: number; label?: string; size?: number }) {
  const radius = size / 2 - 8;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (value / 100) * circumference;
  const color = value >= 80 ? '#ef4444' : value >= 50 ? '#f59e0b' : value >= 25 ? '#3b82f6' : '#22c55e';

  return (
    <div className="relative flex flex-col items-center" style={{ width: size, height: size }}>
      <svg className="absolute inset-0 -rotate-90" width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="6" />
        <circle
          cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth="6"
          strokeDasharray={circumference} strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 1.5s ease-out, stroke 0.5s', filter: `drop-shadow(0 0 4px ${color}80)` }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-bold tabular-nums" style={{ color }}>{value}</span>
        <span className="text-[10px] text-slate-500 uppercase tracking-wider">%</span>
      </div>
    </div>
  );
}

export function RiskBar({ label, weight, color, onClick, active }: { label: string; weight: number; color: string; onClick?: () => void; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full flex items-center gap-3 group transition-all rounded-lg px-2 py-1.5 text-left',
        active && 'bg-white/5'
      )}
    >
      <span className={cn('text-[11px] font-medium w-24 shrink-0', active ? 'text-white' : 'text-slate-400')}>{label}</span>
      <div className="flex-1 h-5 rounded-md bg-white/5 overflow-hidden relative">
        <div
          className="h-full rounded-md transition-all duration-700 group-hover:opacity-80"
          style={{ width: `${weight}%`, backgroundColor: color, boxShadow: `0 0 8px ${color}60` }}
        />
        <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-bold text-white/90">{weight}%</span>
      </div>
    </button>
  );
}
