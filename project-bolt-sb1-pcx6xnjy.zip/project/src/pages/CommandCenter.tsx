import { useState } from 'react';
import { AlertTriangle, TrendingDown, Wind, BedDouble, Users, Activity, ChevronRight, Sparkles, ArrowRight } from 'lucide-react';
import { patients, beds, alerts } from '@/data';
import { GlassCard, SeverityBadge, AnimatedNumber, getSeverityConfig } from '@/components/ui/GlassCard';
import { TelemetryChart } from '@/components/VitalsMonitor';
import { ICUDigitalTwin } from '@/components/ICUDigitalTwin';
import { RiskGauge } from '@/components/RiskGauge';
import { cn } from '@/lib/utils';
import type { Bed } from '@/types';

interface CommandCenterProps {
  onNavigatePatient: (id: string) => void;
  onNavigate: (page: string) => void;
}

export function CommandCenter({ onNavigatePatient, onNavigate }: CommandCenterProps) {
  const [selectedBed, setSelectedBed] = useState<Bed | null>(null);

  const criticalPatients = patients.filter((p) => p.status === 'critical');
  const warningPatients = patients.filter((p) => p.status === 'warning');
  const activeAlerts = alerts.filter((a) => a.status === 'active');
  const ventilatorsActive = patients.filter((p) => p.ventilator?.status === 'active').length;
  const occupiedBeds = beds.filter((b) => b.status === 'occupied').length;

  const metrics = [
    { label: 'Critical Patients', value: criticalPatients.length, icon: AlertTriangle, color: '#ef4444', trend: '+1', trendUp: true, chart: [2, 3, 2, 4, 5] },
    { label: 'Active Alerts', value: activeAlerts.length, icon: Activity, color: '#f59e0b', trend: '−2', trendUp: false, chart: [5, 7, 6, 4, 3] },
    { label: 'Deteriorating', value: warningPatients.length, icon: TrendingDown, color: '#f59e0b', trend: '+1', trendUp: true, chart: [1, 2, 1, 2, 2] },
    { label: 'Ventilators', value: ventilatorsActive, suffix: '/12', icon: Wind, color: '#22d3ee', trend: '0', trendUp: false, chart: [5, 5, 5, 5, 5] },
    { label: 'ICU Occupancy', value: 67, suffix: '%', icon: BedDouble, color: '#a855f7', trend: '+8%', trendUp: true, chart: [55, 58, 60, 63, 67] },
    { label: 'Staff Coverage', value: 92, suffix: '%', icon: Users, color: '#22c55e', trend: '0', trendUp: false, chart: [90, 91, 92, 92, 92] },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Greeting */}
      <div>
        <h1 className="text-2xl lg:text-3xl font-bold text-white">Good Morning, Dr. Mehta</h1>
        <p className="text-sm text-slate-400 mt-1">Here's what needs your attention right now.</p>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {metrics.map((m, i) => {
          const Icon = m.icon;
          return (
            <GlassCard key={m.label} className="p-4 hover:scale-[1.02] transition-transform cursor-default" glow={m.color === '#ef4444' ? 'glow-critical' : ''}>
              <div className="flex items-center justify-between mb-2">
                <div className="p-2 rounded-lg" style={{ backgroundColor: `${m.color}20`, color: m.color }}>
                  <Icon className="h-4 w-4" />
                </div>
                <span className={cn('text-[10px] font-semibold', m.trendUp ? 'text-red-400' : 'text-green-400')}>{m.trend}</span>
              </div>
              <p className="text-[10px] text-slate-500 uppercase tracking-wider font-medium mb-0.5">{m.label}</p>
              <p className="text-2xl font-bold text-white tabular-nums">
                <AnimatedNumber value={m.value} suffix={m.suffix || ''} />
              </p>
              <div className="mt-2 -mx-1">
                <TelemetryChart data={m.chart.map((v, idx) => ({ time: `${idx}`, value: v }))} color={m.color} height={24} />
              </div>
            </GlassCard>
          );
        })}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Critical Patients */}
        <div className="xl:col-span-1 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-red-400" />
              Critical Patients
            </h2>
            <button onClick={() => onNavigate('critical-patients')} className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1">
              View All <ChevronRight className="h-3 w-3" />
            </button>
          </div>

          {[...criticalPatients, ...warningPatients].slice(0, 4).map((patient) => {
            const cfg = getSeverityConfig(patient.status);
            return (
              <button
                key={patient.id}
                onClick={() => onNavigatePatient(patient.id)}
                className={cn(
                  'w-full text-left glass-panel rounded-2xl p-4 hover:scale-[1.02] transition-all border',
                  cfg.border, patient.status === 'critical' && 'critical-pulse'
                )}
              >
                <div className="flex items-start justify-between mb-2">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="text-sm font-bold text-white">{patient.name}</h3>
                      <SeverityBadge severity={patient.status} size="xs" />
                    </div>
                    <p className="text-[11px] text-slate-400">{patient.bed} · {patient.age}{patient.sex}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{patient.diagnosis}</p>
                  </div>
                  <div className="shrink-0">
                    <RiskGauge value={patient.deteriorationRisk} size={60} />
                  </div>
                </div>
                <div className="flex items-center gap-1.5 mt-2 pt-2 border-t border-white/5">
                  {patient.findings.slice(0, 2).map((f, i) => (
                    <span key={i} className="text-[9px] px-2 py-0.5 rounded-full bg-white/5 text-slate-400 capitalize">
                      {f.system}
                    </span>
                  ))}
                  <span className="ml-auto text-[10px] text-cyan-400 flex items-center gap-0.5">
                    Open <ArrowRight className="h-2.5 w-2.5" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* ICU Digital Twin */}
        <div className="xl:col-span-2">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <BedDouble className="h-4 w-4 text-cyan-400" />
              ICU Digital Twin
            </h2>
            <div className="flex items-center gap-3 text-[10px]">
              <span className="flex items-center gap-1 text-green-400"><span className="h-1.5 w-1.5 rounded-full bg-green-400" />Stable</span>
              <span className="flex items-center gap-1 text-amber-400"><span className="h-1.5 w-1.5 rounded-full bg-amber-400" />Warning</span>
              <span className="flex items-center gap-1 text-red-400"><span className="h-1.5 w-1.5 rounded-full bg-red-400" />Critical</span>
            </div>
          </div>
          <div className="glass-panel rounded-2xl overflow-hidden h-[400px] relative">
            <ICUDigitalTwin beds={beds} patients={patients} onBedClick={(bed) => {
              setSelectedBed(bed);
              if (bed.patientId) onNavigatePatient(bed.patientId);
            }} />
          </div>

          {selectedBed && (
            <div className="mt-3 glass-panel rounded-xl p-3 flex items-center justify-between animate-slide-up">
              <div>
                <p className="text-xs font-bold text-white">{selectedBed.label}</p>
                <p className="text-[10px] text-slate-400">{selectedBed.status}</p>
              </div>
              {selectedBed.patientId && (
                <button onClick={() => onNavigatePatient(selectedBed.patientId!)} className="text-[11px] text-cyan-400 hover:text-cyan-300 flex items-center gap-1">
                  Open Patient <ArrowRight className="h-3 w-3" />
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* AI Copilot Summary + ICU Status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel rounded-2xl p-5">
          <div className="flex items-center gap-2.5 mb-3">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold gradient-text-ai">SwiftCare AI Clinical Copilot</h3>
              <p className="text-[10px] text-slate-500">Real-time intelligence summary</p>
            </div>
          </div>
          <p className="text-sm text-slate-300 mb-4">
            <span className="text-red-400 font-semibold">2 patients</span> show early deterioration patterns requiring clinical review.
            Sunita Verma (ICU-03) has a 98% deterioration risk with renal and respiratory involvement. Rajesh Kumar (ICU-07) shows respiratory decline with P/F ratio at 138.
          </p>
          <div className="grid grid-cols-2 gap-3">
            {criticalPatients.concat(warningPatients).slice(0, 2).map((p) => (
              <button key={p.id} onClick={() => onNavigatePatient(p.id)} className="p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-left">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-white">{p.name}</span>
                  <span className="text-xs font-bold" style={{ color: p.deteriorationRisk >= 80 ? '#ef4444' : '#f59e0b' }}>{p.deteriorationRisk}%</span>
                </div>
                <p className="text-[10px] text-slate-400">{p.bed} · {p.diagnosis}</p>
              </button>
            ))}
          </div>
          <button onClick={() => onNavigate('ai-copilot')} className="w-full mt-3 py-2 rounded-xl bg-purple-500/10 text-purple-300 text-xs font-semibold hover:bg-purple-500/20 transition-colors">
            Review All AI Alerts
          </button>
        </div>

        <div className="glass-panel rounded-2xl p-5">
          <h3 className="text-sm font-bold text-white mb-4">ICU Status</h3>
          <div className="space-y-3">
            {[
              { label: 'Occupancy', value: 67, max: 100, unit: '%', color: '#a855f7' },
              { label: 'Ventilators', value: ventilatorsActive, max: 12, unit: '/12', color: '#22d3ee' },
              { label: 'Critical', value: criticalPatients.length, max: 8, unit: '', color: '#ef4444' },
              { label: 'Warnings', value: warningPatients.length, max: 8, unit: '', color: '#f59e0b' },
              { label: 'Stable', value: patients.filter(p => p.status === 'stable').length, max: 8, unit: '', color: '#22c55e' },
            ].map((stat) => (
              <div key={stat.label}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs text-slate-400">{stat.label}</span>
                  <span className="text-xs font-bold text-white tabular-nums">{stat.value}{stat.unit}</span>
                </div>
                <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-1000"
                    style={{ width: `${(stat.value / stat.max) * 100}%`, backgroundColor: stat.color, boxShadow: `0 0 6px ${stat.color}80` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
