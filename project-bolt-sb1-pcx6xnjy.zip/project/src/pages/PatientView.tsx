import { useState } from 'react';
import { ArrowLeft, Brain, Heart, Lungs, Liver, Kidneys, Bone, Zap, Droplet, Activity, Scan } from 'lucide-react';
import type { Patient, OrganKey } from '@/types';
import { SeverityBadge, getSeverityConfig } from '@/components/ui/GlassCard';
import { RiskGauge, RiskBar } from '@/components/RiskGauge';
import { HumanBody3D } from '@/components/HumanBody3D';
import { VitalsGrid, LargeTelemetryChart } from '@/components/VitalsMonitor';
import { AIClinicalCopilot } from '@/components/AIClinicalCopilot';
import { ClinicalTimeline } from '@/components/ClinicalTimeline';
import { OrganRiskMap, OrganDetailPanel } from '@/components/OrganRiskMap';
import { cn } from '@/lib/utils';

const tabs = [
  'Overview', '3D Anatomy', 'Vitals', 'Clinical Chart', 'Labs', 'Medications',
  'Ventilator', 'Imaging', 'Nursing', 'AI Insights', 'Care Team', 'Timeline', 'Documents',
];

interface PatientViewProps {
  patient: Patient;
  onBack: () => void;
  onNavigate: (page: string) => void;
}

export function PatientView({ patient, onBack }: PatientViewProps) {
  const [activeTab, setActiveTab] = useState('Overview');
  const [selectedOrgan, setSelectedOrgan] = useState<OrganKey | null>(null);
  const [selectedVitalIdx, setSelectedVitalIdx] = useState(0);
  const [activeRiskFactor, setActiveRiskFactor] = useState<string | null>(null);

  const cfg = getSeverityConfig(patient.status);
  const organFinding = selectedOrgan ? patient.organFindings.find((f) => f.organ === selectedOrgan) : null;

  return (
    <div className="animate-fade-in pb-20 lg:pb-6">
      {/* Patient Header */}
      <div className={cn('glass-panel rounded-2xl p-4 lg:p-5 mb-4 border', cfg.border, patient.status === 'critical' && 'critical-pulse')}>
        <div className="flex flex-col lg:flex-row lg:items-center gap-4">
          <div className="flex items-center gap-4">
            <button onClick={onBack} className="p-2 rounded-lg glass text-slate-400 hover:text-white transition-colors shrink-0">
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl lg:text-2xl font-bold text-white">{patient.name}</h1>
                <span className="text-sm text-slate-400">{patient.age}{patient.sex}</span>
                <span className="text-sm text-cyan-400 font-medium">{patient.bed}</span>
                <SeverityBadge severity={patient.status} />
              </div>
              <p className="text-xs text-slate-400 mt-1">{patient.diagnosis}</p>
            </div>
          </div>

          <div className="flex items-center gap-6 lg:ml-auto">
            <div className="flex flex-col items-center">
              <RiskGauge value={patient.deteriorationRisk} label="Deterioration" size={90} />
              <p className="text-[9px] text-slate-500 uppercase tracking-wider mt-1">Deterioration</p>
            </div>
            <div className="flex flex-col items-center">
              <RiskGauge value={patient.sepsisRisk} label="Sepsis" size={90} />
              <p className="text-[9px] text-slate-500 uppercase tracking-wider mt-1">Sepsis Risk</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-hide mb-4 pb-1">
        {tabs.map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={cn(
              'px-3.5 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-all',
              activeTab === tab
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'glass text-slate-400 hover:text-white border border-transparent'
            )}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div key={activeTab} className="tab-enter">
        {activeTab === 'Overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
            {/* LEFT: 3D Anatomy */}
            <div className="lg:col-span-4">
              <div className="glass-panel rounded-2xl p-3 h-[400px] lg:h-[500px] relative">
                <div className="absolute top-3 left-3 right-3 z-10 flex items-center justify-between">
                  <h3 className="text-xs font-bold text-white">3D Human Anatomy</h3>
                  <span className="text-[10px] text-cyan-400">Interactive</span>
                </div>
                <HumanBody3D organFindings={patient.organFindings} onOrganSelect={(o) => setSelectedOrgan(o)} />
              </div>
              <div className="mt-4">
                <OrganRiskMap findings={patient.organFindings} onOrganClick={(o) => { setSelectedOrgan(o); setActiveTab('3D Anatomy'); }} />
              </div>
            </div>

            {/* CENTER: Clinical monitoring */}
            <div className="lg:col-span-5 space-y-4">
              <div>
                <h3 className="text-xs font-bold text-white mb-2 flex items-center gap-2">
                  <Activity className="h-3.5 w-3.5 text-cyan-400" />
                  Live Vitals Telemetry
                </h3>
                <VitalsGrid vitals={patient.vitals} compact />
              </div>

              {/* Large telemetry chart */}
              <div>
                <div className="flex gap-1.5 mb-2">
                  {patient.vitals.map((v, i) => (
                    <button
                      key={v.key}
                      onClick={() => setSelectedVitalIdx(i)}
                      className={cn(
                        'px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all',
                        selectedVitalIdx === i ? 'bg-cyan-500/15 text-cyan-300' : 'text-slate-500 hover:text-white'
                      )}
                    >
                      {v.label}
                    </button>
                  ))}
                </div>
                <LargeTelemetryChart vital={patient.vitals[selectedVitalIdx]} height={140} />
              </div>

              {/* Clinical Timeline */}
              <ClinicalTimeline events={patient.timeline} />
            </div>

            {/* RIGHT: AI Copilot + Risk Factors */}
            <div className="lg:col-span-3 space-y-4">
              <AIClinicalCopilot patient={patient} />

              {/* AI Explainability */}
              <div className="glass-panel rounded-2xl p-4">
                <h3 className="text-xs font-bold text-white mb-1">AI Explainability</h3>
                <p className="text-[10px] text-slate-500 mb-3">Why is this patient high risk?</p>
                <div className="flex items-center justify-center mb-3">
                  <RiskGauge value={patient.deteriorationRisk} size={80} />
                </div>
                <div className="space-y-1">
                  {patient.riskFactors.map((rf, i) => {
                    const colors = ['#ef4444', '#f59e0b', '#f59e0b', '#3b82f6', '#22c55e'];
                    return (
                      <RiskBar
                        key={rf.factor}
                        label={rf.factor}
                        weight={rf.weight}
                        color={colors[i] || '#22d3ee'}
                        active={activeRiskFactor === rf.factor}
                        onClick={() => setActiveRiskFactor(activeRiskFactor === rf.factor ? null : rf.factor)}
                      />
                    );
                  })}
                </div>
                {activeRiskFactor && (
                  <p className="text-[10px] text-slate-400 mt-2 p-2 rounded-lg bg-purple-500/10 border border-purple-500/15">
                    Click factors to explore contributing data points on the 3D model and charts.
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === '3D Anatomy' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="lg:col-span-2 glass-panel rounded-2xl p-3 h-[500px] lg:h-[600px] relative">
              <HumanBody3D organFindings={patient.organFindings} onOrganSelect={(o) => setSelectedOrgan(o)} />
            </div>
            <div className="space-y-4">
              {organFinding ? (
                <OrganDetailPanel finding={organFinding} onClose={() => setSelectedOrgan(null)} />
              ) : (
                <>
                  <OrganRiskMap findings={patient.organFindings} onOrganClick={(o) => setSelectedOrgan(o)} />
                  <div className="glass-panel rounded-2xl p-4">
                    <h3 className="text-xs font-bold text-white mb-3">Body System Status</h3>
                    <div className="space-y-2">
                      {patient.organFindings.map((f) => {
                        const cfg = organStatusCfg[f.status];
                        return (
                          <button
                            key={f.organ}
                            onClick={() => setSelectedOrgan(f.organ)}
                            className="w-full flex items-center justify-between p-2.5 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-left"
                          >
                            <div className="flex items-center gap-2">
                              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: cfg.color }} />
                              <span className="text-xs font-medium text-white capitalize">{f.organ}</span>
                            </div>
                            <span className="text-[10px] font-bold uppercase" style={{ color: cfg.color }}>{f.status}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {activeTab === 'Vitals' && (
          <div className="space-y-4">
            <div className="flex gap-1.5 flex-wrap">
              {['5 min', '30 min', '1 hour', '6 hours', '24 hours'].map((tf, i) => (
                <button key={tf} className={cn('px-3 py-1 rounded-lg text-[11px] font-medium', i === 4 ? 'bg-cyan-500/15 text-cyan-300' : 'glass text-slate-400 hover:text-white')}>
                  {tf}
                </button>
              ))}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {patient.vitals.map((v) => <LargeTelemetryChart key={v.key} vital={v} height={160} />)}
            </div>
          </div>
        )}

        {activeTab === 'Labs' && <LabsTab patient={patient} />}
        {activeTab === 'Medications' && <MedicationsTab patient={patient} />}
        {activeTab === 'Ventilator' && <VentilatorTab patient={patient} />}
        {activeTab === 'Imaging' && <ImagingTab patient={patient} />}
        {activeTab === 'AI Insights' && <AIInsightsTab patient={patient} />}
        {activeTab === 'Timeline' && (
          <ClinicalTimeline events={patient.timeline} />
        )}
        {['Clinical Chart', 'Nursing', 'Care Team', 'Documents'].includes(activeTab) && (
          <PlaceholderTab tab={activeTab} patient={patient} />
        )}
      </div>
    </div>
  );
}

const organStatusCfg: Record<string, { color: string }> = {
  stable: { color: '#22c55e' }, monitor: { color: '#3b82f6' },
  elevated: { color: '#f59e0b' }, critical: { color: '#ef4444' },
};

function LabsTab({ patient }: { patient: Patient }) {
  const categories = [...new Set(patient.labs.map(l => l.category))];
  const [activeCat, setActiveCat] = useState(categories[0] || 'CBC');
  const filteredLabs = patient.labs.filter(l => l.category === activeCat);

  return (
    <div className="space-y-4">
      <div className="flex gap-1.5 overflow-x-auto scrollbar-hide">
        {categories.map(cat => (
          <button key={cat} onClick={() => setActiveCat(cat)}
            className={cn('px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap',
              activeCat === cat ? 'bg-cyan-500/15 text-cyan-300' : 'glass text-slate-400 hover:text-white')}>
            {cat}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filteredLabs.map(lab => {
          const isAbnormal = lab.abnormal !== 'normal';
          const trendUp = lab.value > lab.previous;
          return (
            <div key={lab.name} className={cn('glass-panel rounded-xl p-4 hover:scale-[1.01] transition-transform', isAbnormal && 'border-red-500/15')}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-slate-300">{lab.name}</span>
                {isAbnormal && (
                  <span className={cn('text-[9px] font-bold uppercase px-1.5 py-0.5 rounded',
                    lab.abnormal === 'high' ? 'bg-red-500/15 text-red-400' : 'bg-amber-500/15 text-amber-400')}>
                    {lab.abnormal}
                  </span>
                )}
              </div>
              <div className="flex items-baseline gap-2 mb-1">
                <span className={cn('text-2xl font-bold tabular-nums', isAbnormal ? 'text-red-400' : 'text-white')}>{lab.value}</span>
                <span className="text-xs text-slate-500">{lab.unit}</span>
                {isAbnormal && (
                  <span className="text-[10px] text-slate-500">
                    Prev: {lab.previous} {trendUp ? '↑' : '↓'}
                  </span>
                )}
              </div>
              <p className="text-[10px] text-slate-600">Ref: {lab.refLow} – {lab.refHigh}</p>
              <div className="mt-2 h-1.5 rounded-full bg-white/5 overflow-hidden relative">
                <div className="absolute inset-y-0 left-0 bg-green-500/30" style={{
                  left: `${(lab.refLow / (lab.refHigh * 1.5)) * 100}%`,
                  width: `${((lab.refHigh - lab.refLow) / (lab.refHigh * 1.5)) * 100}%`
                }} />
                <div className={cn('absolute top-0 h-full w-1 rounded-full', isAbnormal ? 'bg-red-400' : 'bg-cyan-400')}
                  style={{ left: `${Math.min((lab.value / (lab.refHigh * 1.5)) * 100, 100)}%` }} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function MedicationsTab({ patient }: { patient: Patient }) {
  const statusCfg: Record<string, string> = {
    active: 'text-green-400 bg-green-500/10', 'due-soon': 'text-amber-400 bg-amber-500/10',
    overdue: 'text-red-400 bg-red-500/10', held: 'text-slate-400 bg-white/5',
  };
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold text-white">Active Medications</h3>
      <div className="space-y-2">
        {patient.medications.map(med => (
          <div key={med.id} className="glass-panel rounded-xl p-4 hover:bg-white/5 transition-colors">
            <div className="grid grid-cols-2 md:grid-cols-7 gap-3 items-center">
              <div className="md:col-span-1">
                <p className="text-sm font-semibold text-white">{med.drug}</p>
                {med.highRisk && <span className="text-[9px] text-red-400 font-bold uppercase">High Risk</span>}
              </div>
              <div><p className="text-[10px] text-slate-500">Dose</p><p className="text-xs text-white">{med.dose}</p></div>
              <div><p className="text-[10px] text-slate-500">Route</p><p className="text-xs text-white">{med.route}</p></div>
              <div><p className="text-[10px] text-slate-500">Frequency</p><p className="text-xs text-white">{med.frequency}</p></div>
              <div><p className="text-[10px] text-slate-500">Next Dose</p><p className="text-xs text-cyan-300 font-medium">{med.nextDose}</p></div>
              <div><p className="text-[10px] text-slate-500">Prescriber</p><p className="text-xs text-white">{med.prescriber}</p></div>
              <div className="md:text-right">
                <span className={cn('text-[10px] font-bold uppercase px-2 py-1 rounded-full', statusCfg[med.status])}>{med.status.replace('-', ' ')}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function VentilatorTab({ patient }: { patient: Patient }) {
  if (!patient.ventilator) {
    return <div className="glass-panel rounded-2xl p-8 text-center"><p className="text-slate-400">No ventilator support for this patient.</p></div>;
  }
  const v = patient.ventilator;
  const params = [
    { label: 'FiO₂', value: v.fio2, unit: '%' }, { label: 'PEEP', value: v.peep, unit: 'cmH₂O' },
    { label: 'Tidal Volume', value: v.tidalVolume, unit: 'mL' }, { label: 'Peak Pressure', value: v.peakPressure, unit: 'cmH₂O' },
    { label: 'Mean Airway', value: v.meanAirwayPressure, unit: 'cmH₂O' }, { label: 'RR', value: v.respiratoryRate, unit: '/min' },
  ];
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
      <div className="glass-panel rounded-2xl p-4">
        <h3 className="text-sm font-bold text-white mb-3">Ventilator Status</h3>
        <div className={cn('inline-flex items-center gap-2 px-3 py-1 rounded-full mb-4',
          v.status === 'active' ? 'bg-green-500/15 text-green-400' : 'bg-slate-500/15 text-slate-400')}>
          <span className="h-2 w-2 rounded-full animate-pulse" />
          {v.status.toUpperCase()} — {v.mode}
        </div>
        <div className="grid grid-cols-2 gap-3">
          {params.map(p => (
            <div key={p.label} className="p-3 rounded-xl bg-white/5">
              <p className="text-[10px] text-slate-500 uppercase tracking-wider">{p.label}</p>
              <p className="text-xl font-bold text-cyan-300 tabular-nums">{p.value}<span className="text-xs text-slate-500 ml-1">{p.unit}</span></p>
            </div>
          ))}
        </div>
      </div>
      <div className="lg:col-span-2 glass-panel rounded-2xl p-4">
        <h3 className="text-sm font-bold text-white mb-3">Respiratory Waveforms</h3>
        <div className="space-y-3">
          {['Pressure', 'Flow', 'Volume'].map((wf, i) => (
            <div key={wf}>
              <p className="text-[10px] text-slate-500 mb-1">{wf} Waveform</p>
              <div className="h-16 rounded-lg bg-navy-950/50 telemetry-bg relative overflow-hidden">
                <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none" viewBox="0 0 400 64">
                  <path
                    d={i === 0 ? 'M0,32 Q25,10 50,32 T100,32 T150,32 T200,32 T250,32 T300,32 T350,32 T400,32' :
                       i === 1 ? 'M0,32 L20,5 L40,55 L60,32 L100,32 L120,5 L140,55 L160,32 L200,32 L220,5 L240,55 L260,32 L300,32 L320,5 L340,55 L360,32 L400,32' :
                       'M0,32 Q50,5 100,32 T200,32 T300,32 T400,32'}
                    fill="none" stroke={i === 0 ? '#22d3ee' : i === 1 ? '#a855f7' : '#22c55e'}
                    strokeWidth="1.5"
                  />
                </svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function ImagingTab({ patient }: { patient: Patient }) {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-bold text-white">Medical Imaging</h3>
      <div className="flex gap-1.5">
        {['3D Anatomy', 'CT', 'MRI', 'X-Ray', 'Ultrasound'].map((mode, i) => (
          <button key={mode} className={cn('px-3 py-1.5 rounded-lg text-xs font-medium',
            i === 0 ? 'bg-cyan-500/15 text-cyan-300' : 'glass text-slate-400 hover:text-white')}>{mode}</button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {patient.imaging.length > 0 ? patient.imaging.map((img, i) => (
          <div key={i} className="glass-panel rounded-xl p-4">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300">{img.type}</span>
              <span className="text-xs text-white font-medium">{img.study}</span>
            </div>
            <div className="aspect-video rounded-lg bg-navy-950/60 telemetry-bg flex items-center justify-center mb-2 border border-cyan-500/5">
              <Scan className="h-8 w-8 text-cyan-500/20" />
            </div>
            <p className="text-xs text-slate-300">{img.finding || 'No imaging finding available'}</p>
          </div>
        )) : (
          <div className="col-span-full glass-panel rounded-xl p-8 text-center">
            <p className="text-slate-400">No imaging data available for this patient.</p>
          </div>
        )}
      </div>
    </div>
  );
}

function AIInsightsTab({ patient }: { patient: Patient }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-4">
        <AIClinicalCopilot patient={patient} />
        <div className="glass-panel rounded-2xl p-4">
          <h3 className="text-sm font-bold text-white mb-3">AI Explainability</h3>
          <div className="flex items-center justify-center mb-4">
            <RiskGauge value={patient.deteriorationRisk} size={100} />
          </div>
          <div className="space-y-1.5">
            {patient.riskFactors.map((rf, i) => {
              const colors = ['#ef4444', '#f59e0b', '#f59e0b', '#3b82f6', '#22c55e'];
              return <RiskBar key={rf.factor} label={rf.factor} weight={rf.weight} color={colors[i] || '#22d3ee'} />;
            })}
          </div>
        </div>
      </div>
      <div className="space-y-4">
        <div className="glass-panel rounded-2xl p-4">
          <h3 className="text-sm font-bold text-white mb-3">Clinical Findings</h3>
          {patient.findings.map(f => (
            <div key={f.id} className="p-3 rounded-xl bg-white/5 mb-2">
              <p className="text-sm font-semibold text-white">{f.finding}</p>
              <p className="text-[11px] text-slate-400 mt-1">{f.aiInsight}</p>
              <div className="flex flex-wrap gap-1 mt-2">
                {f.evidence.map((e, i) => (
                  <span key={i} className="text-[9px] px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300">{e}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
        <OrganRiskMap findings={patient.organFindings} />
      </div>
    </div>
  );
}

function PlaceholderTab({ tab, patient }: { tab: string; patient: Patient }) {
  return (
    <div className="glass-panel rounded-2xl p-8">
      <h3 className="text-sm font-bold text-white mb-2">{tab}</h3>
      <p className="text-xs text-slate-400">
        {tab === 'Care Team' && `Attending: ${patient.attendingPhysician} · Nurse: ${patient.nurse}`}
        {tab === 'Nursing' && 'Nursing assessments, interventions, and care documentation.'}
        {tab === 'Clinical Chart' && 'Comprehensive clinical charting and documentation.'}
        {tab === 'Documents' && 'Clinical documents, consents, and reports.'}
      </p>
    </div>
  );
}

import { Scan } from 'lucide-react';
